using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace Test
{
    public interface IOrderProcessingRepository
    {
        Task<IEnumerable<Customer>> GetAllCustomersAsync();
        Task<Customer> GetCustomerByIdAsync(int id);
         Task<Orders> CreateNewOrderAsync(int customerId, List<int> productIds);
         Task<Order> GetOrderByIdAsync(int orderId);
    }
}
