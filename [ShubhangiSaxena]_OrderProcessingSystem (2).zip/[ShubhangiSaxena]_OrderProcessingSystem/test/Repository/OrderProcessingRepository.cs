using YourNamespace.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Test.Repository
{
    public class OrderProcessingRepository : IOrderProcessingRepository
    {
        private readonly DbContext _context;

        public OrderProcessingRepository(DbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Customer>> GetAllCustomersAsync()
        {
            return await _context.Customer.ToListAsync();
        }

        public async Task<Customer> GetCustomerByIdAsync(int id)
        {
            return await _context.Customer.FindAsync(id);
        }


        public async Task<Orders> CreateNewOrderAsync(int customerId, List<int> productIds)
        {
            if (await InCompleteOrderAsync(customerId))
            {
                throw new InvalidOperationException("Cannot place a new order. The customer's previous order is incompleted.");
            }
            var customer = await _context.Customer.FindAsync(customerId);
            if (customer == null) throw new Exception("Customer not found");

            var products = await _context.Products
                .Where(p => productIds.Contains(p.Id))
                .ToListAsync();

            if (!products.Any()) throw new Exception("No valid products found");

            var order = new Orders
            {
                CustomerId = customerId,
                Customer = customer,
                OrderDate = DateTime.UtcNow,
                OrderProducts = products.Select(p => new OrderProduct { ProductId = p.Id }).ToList()
            };

            _context.Orders.Add(order);
            await _context.SaveChangesAsync();

            return order;
        }

        public async Task<bool> InCompleteOrderAsync(int customerId)
        {
            return await _context.Orders
                .AnyAsync(o => o.CustomerId == customerId && o.Status != OrderStatus.Fulfilled);
        }


        public async Task<Order> GetOrderByIdAsync(int orderId)
        {
            return await _context.Orders.FirstOrDefaultAsync(o => o.Id == orderId);
        }


    }
}