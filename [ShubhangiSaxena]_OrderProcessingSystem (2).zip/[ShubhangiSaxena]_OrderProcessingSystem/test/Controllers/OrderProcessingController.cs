﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YourNamespace.Data;
using YourNamespace.Models;
using System.Threading.Tasks;

namespace Test.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderProcessingController : ControllerBase
    {
        private readonly IOrderProcessingRepository _orderProcessingrepo;

        public OrderProcessingController(IOrderProcessingRepository orderProcessingrepo)
        {
            _orderProcessingrepo = orderProcessingrepo;
        }

        // GET: api/customers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
        {
            var customers = await _orderProcessingrepo.GetAllCustomersAsync();
            return Ok(customers);
        }

        // GET: api/customers/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Customer>> GetCustomerById(int id)
        {
            var customer = await _orderProcessingrepo.GetCustomerByIdAsync(id);

            if (customer == null)
            {
                return NotFound();
            }

            return Ok(customer);
        }

        // POST: api/orders
        [HttpPost]
        public async Task<ActionResult<Order>> CreateOrder(int customerId, List<int> productIds)
        {
            try
            {
                var order = await _orderProcessingrepo.CreateNewOrderAsync(customerId, productIds);
                return Ok("", new { id = order.Id }, order);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        // GET: api/orders/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<OrderDetailsDto>> GetOrderById(int id)
        {
            var order = await _orderProcessingrepo.GetOrderByIdAsync(id);

            if (order == null)
            {
                return NotFound();
            }

            var orderDetails = new OrderDetailsDto
            {
                OrderId = order.Id,
                CustomerName = order.Customer.Name,
                OrderDate = order.OrderDate,
                TotalPrice = order.TotalPrice,
                Products = order.OrderProducts.Select(op => new ProductDto
                {
                    ProductId = op.Product.Id,
                    ProductName = op.Product.Name,
                    Price = op.Product.Price
                }).ToList()
            };

            return Ok(orderDetails);
        }
    }
}